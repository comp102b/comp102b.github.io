"""comp102b base controller."""

from cement.ext.ext_argparse import ArgparseController, expose

class BaseController(ArgparseController):
    class Meta:
        label = 'base'
        description = 'Comp 102B Submission module'
        arguments = []

    @expose(help="print help text")
    def help(self):
        print "If you are stuck in any assignment or for any technical issues, contact the TA's : "
        print "Koustuv Sinha, koustuv.sinha@mail.mcgill.ca"
        print "Haji Mohammed Saleem, haji.saleem@mail.mcgill.ca"
