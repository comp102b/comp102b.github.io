# Utility definitions

import json
import os.path
import os
from os.path import expanduser
import jwt
HOME_PATH = expanduser("~")
APP_SECRET = 'comp102b'
from git import Repo
import net_utils as nt
from git import Actor,Repo
GIT_USERNAME = 'comp102b'
GIT_PASSWORD = 'comp102b'

CONFIG_PATH = '.teacher.conf.json'
FULL_CONFIG_PATH = HOME_PATH + '/' + CONFIG_PATH
META_PATH = '.meta.json'

def isConfigured():
    return os.path.exists(FULL_CONFIG_PATH)

def configure(username,token):
    config = {'username' : username, 'token' : token}
    with open(FULL_CONFIG_PATH, 'w') as fp:
        json.dump(config,fp)

def getConfig():
    with open(CONFIG_PATH, 'r') as fp:
        return json.load(fp)

def removeConfig():
    if isConfigured():
        os.remove(FULL_CONFIG_PATH)

def logged_in_user():
    with open(FULL_CONFIG_PATH, 'r') as fp:
        j = json.load(fp)
        m = jwt.decode(j['token'], APP_SECRET, algorithms=['HS256'])
        return m

def get_token():
    with open(FULL_CONFIG_PATH, 'r') as fp:
        j = json.load(fp)
        return j['token']

# setup git for usage in folder
def setup_git():
    with open(HOME_PATH + '/.git-credentials','w') as fp:
        fp.write('http://{}:{}@drgitlab.cs.mcgill.ca'.format(GIT_USERNAME,GIT_PASSWORD))

def teardown_git():
    os.remove(HOME_PATH + '/.git-credentials')

def setup_problem(repo_url,problem_name,isSubmitted):
    cwd = os.getcwd()
    repo_dir = cwd + '/' + problem_name
    setup_git()
    try:
        if os.path.isdir(repo_dir):
            print "Assignment {} already exists, try a different assignment or try in another folder".format(problem_name)
            return
        os.makedirs(repo_dir)
        Repo.clone_from(repo_url, repo_dir)
        repo = Repo(repo_dir)
        # if user has submitted a solution then check out that branch
        if isSubmitted == 1:
            user = logged_in_user()
            repo.git.fetch('origin',user['email'],user['email'])
            repo.git.checkout(user['email'])
        # remove the testing branch
        # edit : does not have the testing branch by default
        # repo.git.branch('-d','testing')
        # remove the remote
        repo.delete_remote('origin')
        print "Assignment {} has been setup in directory {}".format(problem_name,repo_dir)
        print "Solve the assignment using the instructions given in README.md file"
        print "Submit the assignment using the command comp102b submit"
    except:
        repo = Repo(repo_dir)
        repo.delete_remote('origin')
        print "There is an error while setting up the problem. Contact TA."
    teardown_git()

def get_remote(cwd):
    with open(cwd + '/' + META_PATH) as fp:
        meta = json.load(fp)
        problem = nt.getProblem(meta['problem_name'])
        return problem['git']

def checkDirectory():
    if not (os.path.isfile(META_PATH) and (os.path.isdir('src'))):
        print "You are not in the right directory. cd into the assignment directory and re-run."
        return False
    else:
        return True

def submit_problem(cwd):
    if isConfigured():
        user = logged_in_user()
        author = Actor(user['name'], user['email'])
        committer = Actor(user['name'], user['email'])
        # verify the right directory
        if not checkDirectory():
            return False
        remote_url = get_remote(cwd)
        repo = Repo(cwd)
        # checkout in a branch with email of user (or can be used as id)
        # check if branch is present
        try:
            repo.git.checkout('-b',user['email'])
        except:
            repo.git.checkout(user['email'])
        repo.git.add(u=True)
        index = repo.index
        index.commit("submit problem",author=author,committer=committer)
        origin = repo.create_remote('origin', remote_url)
        assert origin.exists()
        # careful, push with some key/username pairs
        setup_git()
        repo.git.push('-u','origin',user['email'])
        teardown_git()
        # delete origin after work
        repo.delete_remote('origin')
        # add the submission in backend
        meta = {}
        with open(META_PATH,'r') as fp:
            meta = json.load(fp)
        username = logged_in_user()['username']
        nt.submit(username,meta['problem_id'],remote_url,user['email'])
        print 'Done!'
    else:
        print "You need to login first to submit an assignment"
