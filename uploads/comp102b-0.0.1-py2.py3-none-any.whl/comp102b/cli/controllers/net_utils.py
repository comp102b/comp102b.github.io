# network interface functions
import requests
import hashlib
import app_utils
import datetime

API_END_PORT = 8092
API_END_PATH = 'http://132.206.3.23:{}'.format(API_END_PORT)
AUTH_HEADER = 'Authorization'
TIME_PATTERN = "%Y-%m-%d %H:%M:%S"


## status codes
UNAUTH = 404
FORBID = 403

def login(username,password):
    hashed_password = hashlib.sha512(password).hexdigest()
    r = requests.post(API_END_PATH + '/login',json={'username' : username, 'password' : hashed_password})
    if r.status_code == FORBID:
        print "Authentication error, cannot log you in"
        return False
    else:
        resp = r.json()
        app_utils.configure(username,resp['key'])
        print "Logged in for username {}".format(username)
        return True

def getProblems():
    if app_utils.isConfigured():
        r = requests.get(API_END_PATH + '/problems',headers={AUTH_HEADER : app_utils.get_token()})
        if r.status_code == FORBID:
            print "Authentication error, you cannot view assignments"
            return False
        else:
            resp = r.json()
            return resp
    else:
        print "Please login to view assignments"
        return []

def getProblem(problem):
    if app_utils.isConfigured():
        r = requests.get(API_END_PATH + '/problems',headers={AUTH_HEADER : app_utils.get_token()})
        if r.status_code == FORBID:
            print "Authentication error, you cannot get the assignment"
            return False
        else:
            resp = r.json()
            for r in resp:
                if r['title'] == problem:
                    return r
            return None
    else:
        print "Please login to view assignments"
        return None

def submit(username,problem_id,git,branch):
    if app_utils.isConfigured():
        submit_time = datetime.datetime.now().strftime(TIME_PATTERN)
        r = requests.post(API_END_PATH + '/submit', headers={AUTH_HEADER : app_utils.get_token()},
            json={
                'submit_time' : submit_time,
                'git' : git,
                'problem_id' : problem_id,
                'branch' : branch,
                'username' : username,
            }
        )
        if r.status_code == FORBID:
            print "Authentication error, you cannot submit assignment. Contact TA."
            return False
        else:
            return True
    else:
        print "You need to login to submit assignment"
        return False
