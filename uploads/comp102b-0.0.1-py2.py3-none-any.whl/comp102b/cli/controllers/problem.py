from cement.ext.ext_argparse import ArgparseController, expose
import net_utils as nt
import app_utils
from terminaltables import AsciiTable
import os
import subprocess
prompt = '> '

class ProblemsController(ArgparseController):
    class Meta:
        label = 'assignments'
        description = 'Comp 102B submission module'
        arguments = []

    @expose(help="Display available assignments")
    def assignments(self):
        print "Displaying assignments"
        problems = nt.getProblems()
        if len(problems) == 0:
            print "No assignments found"
            return
        headers = ['Assignment name','Assignment description','Points','Due date','Last submit time']
        table = [headers]
        for p in problems:
            row = [p['title'],p['description'],p['points'],p['soft_deadline']]
            if p['submitted'] == 1:
                row.append(p['last_submit_date'])
            else:
                row.append('')
            table.append(row)
        tb = AsciiTable(table)
        print tb.table

    @expose(help="Start a specific assignment")
    def start(self):
        print "Enter assignment name"
        print "See available assignments using comp102b assignments"
        problem_name = raw_input(prompt)
        problem = nt.getProblem(problem_name)
        if not problem:
            print "Assignment with name {} not found".format(problem_name)
            return
        else:
            app_utils.setup_problem(problem['git'],problem_name,problem['submitted'])
            print "Setup done"

    @expose(help="Submit your work")
    def submit(self):
        print "Submitting your work, please wait ..."
        cwd = os.getcwd()
        app_utils.submit_problem(cwd)

    @expose(help="Run your assignment locally")
    def run(self):
        if app_utils.checkDirectory():
            cwd = os.getcwd()
            subprocess.call(['python',cwd + '/main.py'])
