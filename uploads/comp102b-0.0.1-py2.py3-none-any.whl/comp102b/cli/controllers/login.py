"""login controller."""

from cement.ext.ext_argparse import ArgparseController, expose
import app_utils as ut
import net_utils as net
import getpass

class LoginController(ArgparseController):
    class Meta:
        label = 'login'
        description = 'Comp 102B submission module'
        arguments = []

    @expose(hide=True)
    def default(self):
        print("Inside LoginController.default().")

    @expose(help="Login to the system with your credentials")
    def login(self):
        print "Logging you in"
        if ut.isConfigured():
            print "You are logged in"
        else:
            print "Provide username"
            prompt = '> '
            username = raw_input(prompt)
            print "Password"
            password = getpass.getpass(prompt)
            net.login(username,password)

    @expose(help="Logout from the system")
    def logout(self):
        print "Logging you out"
        ut.removeConfig()
        print "Logged out"

    @expose(help="See user info")
    def whoami(self):
        m = ut.logged_in_user()
        print 'Username : {}, Email : {}'.format(m['username'],m['email'])
