"""comp102b bootstrapping."""

# All built-in application controllers should be imported, and registered
# in this file in the same way as BaseController.

from comp102b.cli.controllers.base import BaseController
from comp102b.cli.controllers.login import LoginController
from comp102b.cli.controllers.problem import ProblemsController

def load(app):
    app.handler.register(BaseController)
    app.handler.register(LoginController)
    app.handler.register(ProblemsController)
