"""CLI tests for comp102b."""

from comp102b.utils import test

class CliTestCase(test.TestCase):
    def test_comp102b_cli(self):
        argv = ['--foo=bar']
        with self.make_app(argv=argv) as app:
            app.run()
            self.eq(app.pargs.foo, 'bar')
